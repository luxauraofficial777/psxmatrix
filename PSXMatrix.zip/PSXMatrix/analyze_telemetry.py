#!/usr/bin/env python3
"""
analyze_telemetry.py — PSX Meta-Harness Telemetry Synthesizer

Parses matrix_summary.json, per-test _telemetry.json files, and raw stdout/stderr
logs from the PSX meta-harness. Applies diagnostic pattern matching to classify
each test node by execution stage, failure mode, and G2-pass threshold.

Usage:
    python analyze_telemetry.py [--log-dir PATH] [--summary PATH] [--json] [--no-color]

Outputs:
    - Console: aggregated diagnostic report with per-test breakdown
    - JSON (with --json): structured report to analyze_report.json
"""

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# ANSI Colors
# ---------------------------------------------------------------------------
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    CYAN    = "\033[96m"
    MAGENTA = "\033[95m"
    GREY    = "\033[90m"

    @staticmethod
    def enabled() -> bool:
        return sys.stdout.isatty() and os.environ.get("NO_COLOR", "") == ""


def c(color: str, text: str) -> str:
    if C.enabled():
        return f"{color}{text}{C.RESET}"
    return text


# ---------------------------------------------------------------------------
# Diagnostic Patterns
# ---------------------------------------------------------------------------
@dataclass
class DiagPattern:
    name: str
    label: str
    patterns: list  # list of compiled regex
    severity: str   # "info", "warn", "critical"


PATTERNS = [
    DiagPattern(
        name="INSERT_DISC_LOOP",
        label="Insert/Wrong Disc Loop",
        patterns=[
            re.compile(r"INSERT\s+DISC", re.IGNORECASE),
            re.compile(r"WRONG\s+DISC", re.IGNORECASE),
            re.compile(r"please\s+insert", re.IGNORECASE),
            re.compile(r"disc\s+error", re.IGNORECASE),
        ],
        severity="warn",
    ),
    DiagPattern(
        name="LBA_SEEK_FMV",
        label="FMV Seek Target (32:34:71 / LBA 146621)",
        patterns=[
            re.compile(r"32:34:71"),
            re.compile(r"146621"),
            re.compile(r"LBA\s+146621", re.IGNORECASE),
            re.compile(r"0*23CAD", re.IGNORECASE),  # 146621 in hex
        ],
        severity="info",
    ),
    DiagPattern(
        name="BIOS_POST_COMPLETE",
        label="BIOS POST / Kernel Initialized",
        patterns=[
            re.compile(r"KERNEL\s+SETUP", re.IGNORECASE),
            re.compile(r"Kernel\s+initialized", re.IGNORECASE),
            re.compile(r"PS-X\s+Realtime\s+Kernel", re.IGNORECASE),
            re.compile(r"POST\s+complete", re.IGNORECASE),
            re.compile(r"BOOTSTRAP\s+LOADER", re.IGNORECASE),
            re.compile(r"System\s+ROM\s+Version", re.IGNORECASE),
        ],
        severity="info",
    ),
    DiagPattern(
        name="GPU_INITIALIZED",
        label="GPU Active (FPS / GPU registers)",
        patterns=[
            re.compile(r"FPS[:\s]*\d+", re.IGNORECASE),
            re.compile(r"GPU_DIAG", re.IGNORECASE),
            re.compile(r"GP0_cmds\s*[=:]\s*\d+", re.IGNORECASE),
            re.compile(r"VRAM_writes\s*[=:]\s*\d+", re.IGNORECASE),
            re.compile(r"display_enabled\s*[=:]\s*1", re.IGNORECASE),
            re.compile(r"fb_dirty\s*[=:]\s*1", re.IGNORECASE),
        ],
        severity="info",
    ),
    DiagPattern(
        name="CDROM_READ_ACTIVE",
        label="CD-ROM Read Active (CdRead / CdlRead)",
        patterns=[
            re.compile(r"CdRead", re.IGNORECASE),
            re.compile(r"CdlRead", re.IGNORECASE),
            re.compile(r"cdrom.*read", re.IGNORECASE),
            re.compile(r"sector.*read", re.IGNORECASE),
            re.compile(r"advance_sector", re.IGNORECASE),
            re.compile(r"reading\s+sector", re.IGNORECASE),
        ],
        severity="info",
    ),
    DiagPattern(
        name="UNMAPPED_MEMORY_CRASH",
        label="Unmapped Memory Crash (0x800D9E80 region)",
        patterns=[
            re.compile(r"unhandled\s+exception", re.IGNORECASE),
            re.compile(r"unmapped\s+memory", re.IGNORECASE),
            re.compile(r"access\s+violation", re.IGNORECASE),
            re.compile(r"0x800D9E80", re.IGNORECASE),
            re.compile(r"0*800D9E[0-9A-Fa-f]{2}"),
            re.compile(r"memory\s+boundary\s+fault", re.IGNORECASE),
            re.compile(r"segmentation\s+fault", re.IGNORECASE),
            re.compile(r"panic.*0x800[0-9A-Fa-f]+", re.IGNORECASE),
        ],
        severity="critical",
    ),
    DiagPattern(
        name="CDROM_COMMAND_UNIMPL",
        label="Unimplemented CD-ROM Command (StarPSX)",
        patterns=[
            re.compile(r"not\s+implemented:\s*cdrom\s+command", re.IGNORECASE),
            re.compile(r"unimplemented.*cdrom", re.IGNORECASE),
        ],
        severity="critical",
    ),
    DiagPattern(
        name="BOOT_EXE_FOUND",
        label="Boot EXE Located (SYSTEM.CNF parsed)",
        patterns=[
            re.compile(r"SYSTEM\.CNF", re.IGNORECASE),
            re.compile(r"BOOT\s*=\s*cdrom:", re.IGNORECASE),
            re.compile(r"SLUSP\d+", re.IGNORECASE),
            re.compile(r"EXEC:PC0", re.IGNORECASE),
            re.compile(r"boot\s+file\s*:", re.IGNORECASE),
            re.compile(r"Execute\s*!", re.IGNORECASE),
        ],
        severity="info",
    ),
    DiagPattern(
        name="BOOT_FAIL_NO_EXE",
        label="Boot Failure (No EXE in SYSTEM.CNF)",
        patterns=[
            re.compile(r"BOOT_FAIL", re.IGNORECASE),
            re.compile(r"No\s+boot\s+EXE", re.IGNORECASE),
            re.compile(r"Pass_Status.*BOOT_FAIL", re.IGNORECASE),
        ],
        severity="critical",
    ),
]

# G2-pass threshold: test must show BIOS_POST_COMPLETE + BOOT_EXE_FOUND
# and NOT show UNMAPPED_MEMORY_CRASH or BOOT_FAIL_NO_EXE
G2_REQUIRED = {"BIOS_POST_COMPLETE", "BOOT_EXE_FOUND"}
G2_BLOCKING = {"UNMAPPED_MEMORY_CRASH", "BOOT_FAIL_NO_EXE", "CDROM_COMMAND_UNIMPL"}


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------
@dataclass
class TestDiagnostic:
    test_id: str
    emulator: str
    bios_mode: str
    disc: str
    status: str
    exit_code: Optional[int]
    duration_seconds: float
    detected_flags: list = field(default_factory=list)
    flag_details: dict = field(default_factory=dict)
    g2_pass: bool = False
    failure_mode: str = ""
    stdout_lines: int = 0
    stderr_lines: int = 0
    stdout_size: int = 0
    stderr_size: int = 0
    error_message: str = ""


# ---------------------------------------------------------------------------
# Core Logic
# ---------------------------------------------------------------------------
def scan_text(text: str) -> dict:
    """Scan text for all diagnostic patterns. Returns {flag_name: [matches]}."""
    results = {}
    for pat in PATTERNS:
        matches = []
        for regex in pat.patterns:
            found = regex.findall(text)
            if found:
                matches.extend(found[:5])  # cap at 5 matches per pattern
        if matches:
            results[pat.name] = matches
    return results


def classify_failure_mode(flags: dict, status: str, exit_code: Optional[int]) -> str:
    """Classify the primary failure mode for a test."""
    if "UNMAPPED_MEMORY_CRASH" in flags:
        return "UNMAPPED_MEMORY_CRASH"
    if "CDROM_COMMAND_UNIMPL" in flags:
        return "CDROM_COMMAND_UNIMPL"
    if "BOOT_FAIL_NO_EXE" in flags:
        return "BOOT_FAIL_NO_EXE"
    if "INSERT_DISC_LOOP" in flags:
        return "INSERT_DISC_LOOP"
    if status == "TIMEOUT_HANG":
        if "BIOS_POST_COMPLETE" in flags and "BOOT_EXE_FOUND" in flags:
            return "STALL_AFTER_BOOT"
        if "BIOS_POST_COMPLETE" in flags:
            return "STALL_IN_KERNEL"
        return "STALL_PRE_BOOT"
    if status == "FAILED" and exit_code is not None:
        return f"EXIT_{exit_code}"
    if status == "PASSED":
        return "OK"
    return "UNKNOWN"


def evaluate_g2(flags: dict, status: str) -> bool:
    """G2-pass: required flags present, no blocking flags, clean exit."""
    flag_names = set(flags.keys())
    if flag_names & G2_BLOCKING:
        return False
    if not (G2_REQUIRED & flag_names):
        return False
    # Must have all required flags
    if not G2_REQUIRED.issubset(flag_names):
        return False
    return True


def load_json_safe(path: Path) -> dict:
    """Load JSON file, return empty dict on error."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError, OSError):
        return {}


def read_text_safe(path: Path) -> str:
    """Read text file, return empty string on error."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except (FileNotFoundError, OSError):
        return ""


def analyze_test(test_result: dict, log_dir: Path) -> TestDiagnostic:
    """Analyze a single test result from the summary."""
    test_id = test_result.get("test_id", "unknown")

    # Load per-test telemetry JSON
    telemetry_path = log_dir / f"{test_id}_telemetry.json"
    telemetry = load_json_safe(telemetry_path)

    # Merge: summary result takes priority, telemetry fills gaps
    merged = {**telemetry, **test_result}

    # Read stdout and stderr logs
    stdout_path = Path(merged.get("stdout_file", log_dir / f"{test_id}_stdout.txt"))
    stderr_path = Path(merged.get("stderr_file", log_dir / f"{test_id}_stderr.txt"))

    stdout_text = read_text_safe(stdout_path)
    stderr_text = read_text_safe(stderr_path)
    combined_text = stdout_text + "\n" + stderr_text

    # Also scan the telemetry JSON itself for Cybergrime-specific fields
    telemetry_str = json.dumps(telemetry) if telemetry else ""
    full_scan_text = combined_text + "\n" + telemetry_str

    # Run pattern matching
    flags = scan_text(full_scan_text)

    status = merged.get("status", "UNKNOWN")
    exit_code = merged.get("exit_code")
    duration = merged.get("duration_seconds", 0.0)

    g2 = evaluate_g2(flags, status)
    failure_mode = classify_failure_mode(flags, status, exit_code)

    diag = TestDiagnostic(
        test_id=test_id,
        emulator=merged.get("emulator", "?"),
        bios_mode=merged.get("bios_mode", "?"),
        disc=merged.get("disc", "?"),
        status=status,
        exit_code=exit_code,
        duration_seconds=round(duration, 3),
        detected_flags=list(flags.keys()),
        flag_details={k: v[:3] for k, v in flags.items()},  # cap details at 3
        g2_pass=g2,
        failure_mode=failure_mode,
        stdout_lines=merged.get("stdout_line_count", 0),
        stderr_lines=merged.get("stderr_line_count", 0),
        stdout_size=merged.get("stdout_size_bytes", len(stdout_text.encode("utf-8"))),
        stderr_size=merged.get("stderr_size_bytes", len(stderr_text.encode("utf-8"))),
        error_message=merged.get("error_message", ""),
    )
    return diag


# ---------------------------------------------------------------------------
# Report Generation
# ---------------------------------------------------------------------------
def status_badge(status: str) -> str:
    if status == "PASSED":
        return c(C.GREEN + C.BOLD, " PASSED ")
    if status == "FAILED":
        return c(C.RED + C.BOLD, " FAILED ")
    if status == "TIMEOUT_HANG":
        return c(C.YELLOW + C.BOLD, " TIMEOUT ")
    return c(C.GREY, f" {status} ")


def g2_badge(g2: bool) -> str:
    if g2:
        return c(C.GREEN + C.BOLD, "G2-PASS")
    return c(C.RED, "G2-FAIL")


def severity_color(flag_name: str) -> str:
    for pat in PATTERNS:
        if pat.name == flag_name:
            if pat.severity == "critical":
                return C.RED
            if pat.severity == "warn":
                return C.YELLOW
            return C.CYAN
    return C.GREY


def print_report(diagnostics: list, summary: dict, args):
    """Print the aggregated diagnostic report to console."""
    print()
    print(c(C.BLUE + C.BOLD, "=" * 80))
    print(c(C.BLUE + C.BOLD, "  PSX META-HARNESS — TELEMETRY DIAGNOSTIC REPORT"))
    print(c(C.BLUE + C.BOLD, "=" * 80))

    # Run metadata
    run_id = summary.get("matrix_run_id", "?")
    tag = summary.get("tag", "(none)")
    total_dur = summary.get("total_duration_seconds", 0)
    config = summary.get("configuration", {})

    print(f"  Run ID:       {run_id}")
    print(f"  Tag:          {tag}")
    print(f"  Duration:     {total_dur:.1f}s total")
    print(f"  Emulators:    {', '.join(config.get('emulators', []))}")
    print(f"  BIOS modes:   {', '.join(config.get('bios_modes', []))}")
    print(f"  Discs:        {', '.join(config.get('discs', []))}")
    print(f"  Timeout:      {config.get('timeout_seconds', '?')}s per test")
    print()

    # Summary counts
    s = summary.get("summary", {})
    total = s.get("total_tests", len(diagnostics))
    passed = sum(1 for d in diagnostics if d.status == "PASSED")
    failed = sum(1 for d in diagnostics if d.status == "FAILED")
    timeout = sum(1 for d in diagnostics if d.status == "TIMEOUT_HANG")
    g2_pass_count = sum(1 for d in diagnostics if d.g2_pass)

    print(c(C.BOLD, "  OVERVIEW"))
    print(f"    Total tests:    {total}")
    print(f"    {c(C.GREEN, f'Passed: {passed}')}   {c(C.RED, f'Failed: {failed}')}   {c(C.YELLOW, f'Timeout: {timeout}')}")
    print(f"    {g2_badge(g2_pass_count > 0)}: {g2_pass_count}/{total} tests reached G2 execution threshold")
    print()

    # Per-test breakdown
    print(c(C.BOLD, "  PER-TEST DIAGNOSTICS"))
    print(c(C.GREY, "  " + "-" * 78))

    for diag in diagnostics:
        badge = status_badge(diag.status)
        g2 = g2_badge(diag.g2_pass)

        print()
        print(f"  {c(C.BOLD, diag.test_id)}")
        print(f"    {badge}  {g2}  exit={diag.exit_code}  dur={diag.duration_seconds}s")
        print(f"    Emulator: {diag.emulator}  BIOS: {diag.bios_mode}  Disc: {diag.disc}")
        print(f"    Failure mode: {c(C.YELLOW, diag.failure_mode)}")

        if diag.error_message:
            print(f"    Error: {c(C.RED, diag.error_message)}")

        if diag.detected_flags:
            print(f"    Detected flags:")
            for flag in diag.detected_flags:
                color = severity_color(flag)
                details = diag.flag_details.get(flag, [])
                detail_str = f" ({', '.join(str(d) for d in details[:3])})" if details else ""
                print(f"      {c(color, flag)}{c(C.GREY, detail_str)}")
        else:
            print(f"    Detected flags: {c(C.GREY, '(none)')}")

        io_info = []
        if diag.stdout_lines:
            io_info.append(f"stdout={diag.stdout_lines}L/{diag.stdout_size}B")
        if diag.stderr_lines:
            io_info.append(f"stderr={diag.stderr_lines}L/{diag.stderr_size}B")
        if io_info:
            print(f"    I/O: {c(C.GREY, ', '.join(io_info))}")

    print()
    print(c(C.GREY, "  " + "-" * 78))

    # G2-pass categorization
    g2_passed = [d for d in diagnostics if d.g2_pass]
    g2_failed = [d for d in diagnostics if not d.g2_pass]

    print()
    print(c(C.BOLD, "  G2-PASS CATEGORIZATION"))
    print()

    if g2_passed:
        print(f"    {c(C.GREEN + C.BOLD, 'G2-PASSED')} ({len(g2_passed)} tests):")
        for d in g2_passed:
            print(f"      {c(C.GREEN, '+')} {d.test_id}  [{d.failure_mode}]")
        print()

    if g2_failed:
        # Group by failure mode
        by_mode = {}
        for d in g2_failed:
            by_mode.setdefault(d.failure_mode, []).append(d)

        print(f"    {c(C.RED + C.BOLD, 'G2-FAILED')} ({len(g2_failed)} tests):")
        for mode, tests in sorted(by_mode.items()):
            print(f"      {c(C.YELLOW, mode)} ({len(tests)}):")
            for d in tests:
                flags_str = ", ".join(d.detected_flags) if d.detected_flags else "(no flags)"
                print(f"        {c(C.RED, '-')} {d.test_id}  flags=[{c(C.GREY, flags_str)}]")
        print()

    # FMV seek loop detection
    fmv_tests = [d for d in diagnostics if "LBA_SEEK_FMV" in d.detected_flags]
    if fmv_tests:
        print(f"    {c(C.MAGENTA, 'FMV SEEK LOOP DETECTED')} in {len(fmv_tests)} test(s):")
        for d in fmv_tests:
            print(f"      {d.test_id}  [{d.failure_mode}]")
        print()

    # Memory crash detection
    crash_tests = [d for d in diagnostics if "UNMAPPED_MEMORY_CRASH" in d.detected_flags]
    if crash_tests:
        print(f"    {c(C.RED + C.BOLD, 'MEMORY CRASH DETECTED')} in {len(crash_tests)} test(s):")
        for d in crash_tests:
            print(f"      {d.test_id}  [{d.failure_mode}]")
        print()

    # CD-ROM command unimplemented
    unimpl_tests = [d for d in diagnostics if "CDROM_COMMAND_UNIMPL" in d.detected_flags]
    if unimpl_tests:
        print(f"    {c(C.YELLOW, 'CD-ROM COMMAND UNIMPLEMENTED')} in {len(unimpl_tests)} test(s):")
        for d in unimpl_tests:
            print(f"      {d.test_id}  [{d.failure_mode}]")
        print()

    print(c(C.BLUE + C.BOLD, "=" * 80))
    print()


def generate_json_report(diagnostics: list, summary: dict, output_path: Path):
    """Generate structured JSON report."""
    report = {
        "report_type": "PSX_META_HARNESS_TELEMETRY_ANALYSIS",
        "matrix_run_id": summary.get("matrix_run_id", ""),
        "tag": summary.get("tag", ""),
        "total_duration_seconds": summary.get("total_duration_seconds", 0),
        "configuration": summary.get("configuration", {}),
        "overview": {
            "total_tests": len(diagnostics),
            "passed": sum(1 for d in diagnostics if d.status == "PASSED"),
            "failed": sum(1 for d in diagnostics if d.status == "FAILED"),
            "timeout_hang": sum(1 for d in diagnostics if d.status == "TIMEOUT_HANG"),
            "g2_pass_count": sum(1 for d in diagnostics if d.g2_pass),
            "g2_fail_count": sum(1 for d in diagnostics if not d.g2_pass),
        },
        "g2_passed": [d.test_id for d in diagnostics if d.g2_pass],
        "g2_failed": {
            mode: [d.test_id for d in diagnostics if not d.g2_pass and d.failure_mode == mode]
            for mode in sorted({d.failure_mode for d in diagnostics if not d.g2_pass})
        },
        "fmv_seek_loop_detected": [d.test_id for d in diagnostics if "LBA_SEEK_FMV" in d.detected_flags],
        "memory_crash_detected": [d.test_id for d in diagnostics if "UNMAPPED_MEMORY_CRASH" in d.detected_flags],
        "cdrom_unimpl_detected": [d.test_id for d in diagnostics if "CDROM_COMMAND_UNIMPL" in d.detected_flags],
        "tests": [asdict(d) for d in diagnostics],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    return output_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Analyze PSX meta-harness telemetry and logs for diagnostic patterns.",
    )
    parser.add_argument(
        "--log-dir",
        type=str,
        default=None,
        help="Path to matrix_logs/ directory (default: auto-detect from summary)",
    )
    parser.add_argument(
        "--summary",
        type=str,
        default=None,
        help="Path to matrix_summary.json (default: search alongside log-dir)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Also output structured JSON report to analyze_report.json",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI color output",
    )
    args = parser.parse_args()

    if args.no_color:
        os.environ["NO_COLOR"] = "1"

    # Resolve paths
    script_dir = Path(__file__).resolve().parent
    default_log_dir = script_dir / "matrix_logs"
    default_summary = script_dir / "matrix_summary.json"

    log_dir = Path(args.log_dir) if args.log_dir else default_log_dir
    summary_path = Path(args.summary) if args.summary else default_summary

    if not summary_path.exists():
        print(c(C.RED + C.BOLD, f"ERROR: matrix_summary.json not found at {summary_path}"))
        sys.exit(1)

    if not log_dir.exists():
        print(c(C.RED + C.BOLD, f"ERROR: matrix_logs/ directory not found at {log_dir}"))
        sys.exit(1)

    # Load summary
    summary = load_json_safe(summary_path)
    if not summary:
        print(c(C.RED + C.BOLD, f"ERROR: Failed to parse {summary_path}"))
        sys.exit(1)

    results = summary.get("results", [])
    if not results:
        print(c(C.YELLOW, "WARNING: No test results found in summary."))
        sys.exit(0)

    # Analyze each test
    diagnostics = []
    for test_result in results:
        diag = analyze_test(test_result, log_dir)
        diagnostics.append(diag)

    # Print console report
    print_report(diagnostics, summary, args)

    # Optional JSON output
    if args.json:
        output_path = script_dir / "analyze_report.json"
        generate_json_report(diagnostics, summary, output_path)
        print(c(C.GREEN, f"JSON report written to: {output_path}"))


if __name__ == "__main__":
    main()
