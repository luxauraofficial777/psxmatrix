#!/usr/bin/env python3
"""
PSXMatrix/digital_twin.py — Phased Digital Twin Facade & CLI Delegate
---------------------------------------------------------------------
Delegates directly to the modular, 4-phase dual-pass Digital Twin pipeline in
`verify/run_digital_twin.py`. Maintains 100% backward compatibility for all
CLI flags (--build-log, --matrix-summary, --log-dir, --json, --quiet).
"""

import argparse
import os
import sys
from pathlib import Path

# Add project root and verify directory to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
VERIFY_DIR = PROJECT_ROOT / "verify"
sys.path.insert(0, str(VERIFY_DIR))

import run_digital_twin


def main():
    parser = argparse.ArgumentParser(description="PSX Matrix Digital Twin Facade")
    parser.add_argument("--build-log", type=str, help="Path to CyberGrime builder stdout log")
    parser.add_argument("--matrix-summary", type=str, help="Path to matrix_summary.json")
    parser.add_argument("--log-dir", type=str, help="Path to matrix logs directory")
    parser.add_argument("--disc", type=str, help="Path to disc .bin/.cue file")
    parser.add_argument("--phase", type=int, choices=[1, 2, 3, 4], help="Run specific phase (1..4)")
    parser.add_argument("--json", action="store_true", help="Output JSON diagnosis to stdout")
    parser.add_argument("--quiet", action="store_true", help="Suppress console summary output")
    args = parser.parse_args()

    results = run_digital_twin.run_all_phases(
        disc_path=args.disc,
        build_log_path=args.build_log,
        matrix_summary_path=args.matrix_summary,
        root_dir=str(PROJECT_ROOT),
        target_phase=args.phase,
    )

    if args.json:
        diag_path = PROJECT_ROOT / "build_staging" / "digital_twin_diagnosis.json"
        if diag_path.exists():
            with open(diag_path, 'r', encoding='utf-8') as f:
                print(f.read())
    elif not args.quiet:
        p4 = results.get("phase4", {})
        if p4:
            print(f"\n[PSXMatrix Digital Twin] Phased Dual-Pass Complete:")
            print(f"  Failure Mode:       {p4.get('failure_mode')}")
            print(f"  Highest Checkpoint: {p4.get('highest_checkpoint')}")
            print(f"  Blocker Checkpoint: {p4.get('blocker_checkpoint')}")
            print(f"  Report written to:  study/digital_twin_report.md")

    return 0


if __name__ == '__main__':
    sys.exit(main())
