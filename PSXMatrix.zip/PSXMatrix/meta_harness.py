#!/usr/bin/env python3
"""
meta_harness.py - PSX Multi-Emulator x Multi-BIOS Test Matrix Runner

Automates systematic testing of PlayStation 1 reverse-engineering builds
across multiple emulators (Cybergrime, DuckStation, PSXE) and BIOS
configurations (HLE, VHB Super BIOS, SCPH-1001).

For each Emulator x BIOS x Disc combination, the harness:
  1. Auto-configures emulator settings (DuckStation ini, etc.).
  2. Launches the emulator with the appropriate flags and disc.
  3. Streams stdout/stderr live to the console while saving to log files.
  4. Enforces a strict timeout to detect hangs and infinite loops.
  5. Generates a structured _telemetry.json per test.
  6. Aggregates all results into a master matrix_summary.json.

Usage:
    python meta_harness.py [options]

Options:
    --timeout N          Per-test timeout in seconds (default: 30)
    --disc NAME          Disc to test: frankenstein or dw7 (default: both)
    --iso PATH           Explicit path to disc .cue/.bin (overrides --disc)
    --vhb-bios PATH      Path to VHB Super BIOS
    --scph-bios PATH     Path to SCPH-1001 BIOS
    --log-dir PATH       Output directory for logs (default: ./matrix_logs)
    --emulator NAME      Run only one emulator (cybergrime|duckstation|psxe)
    --bios-mode MODE     Run only one BIOS mode (hle|vhb|scph)
    --max-instr N        Max instructions for Cybergrime (default: 5000000)
    --max-output-lines N Max lines of live output per test (0=unlimited, default: 50)
    --dry-run            Print commands without executing
    --clean              Clear log directory before running
    --quiet              Suppress live emulator output (show status only)
"""

import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent

# Absolute paths to project assets (no guessing — verified on disk Aug 4 2026)
DQ_ROOT = Path(r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION")

DEFAULT_TIMEOUT = 60
DEFAULT_LOG_DIR = str(PROJECT_ROOT / "matrix_logs")
DEFAULT_MAX_INSTR = 5_000_000
DEFAULT_MAX_OUTPUT_LINES = 50

# Per-emulator timeout multipliers (some emulators need more time)
EMULATOR_TIMEOUT_MULT = {
    "cybergrime": 1.0,   # instruction-limited, exits on its own
    "duckstation": 1.0,  # batch mode, exits on power-off
    "starpsx": 1.0,       # GUI emulator, exits on window close
}

# Disc library — each disc has a label and a .cue path
DISCS = {
    "frankenstein": {
        "label": "Frankenstein Master (DQ4 HBD on DW7 base)",
        "cue": str(DQ_ROOT / "frankenstein_pipeline" / "output" / "dq4_frankenstein.cue"),
    },
    "reverse_a": {
        "label": "Reverse Frankenstein Option A (DQ4 disc base + DW7 EXE swap)",
        "cue": str(DQ_ROOT / "dq4_reverse_a.cue"),
    },
    "v99": {
        "label": "Frankenstein v99 (Hydra Loop build_staging output)",
        "cue": str(DQ_ROOT / "build_staging" / "dq4_frankenstein_v99.cue"),
    },
    "dw7": {
        "label": "DW7 Native US (Dragon Warrior VII Disc 1)",
        "cue": str(DQ_ROOT / "DW7D1" / "DW7D1.cue"),
    },
}

# BIOS files
DEFAULT_VHB_BIOS = str(DQ_ROOT / "VHB_SUPER_BIOS_V1.00A" / "FRANKENSTEIN.BIOS")
DEFAULT_SCPH_BIOS = str(DQ_ROOT / "bios" / "US" / "SCPH1001.BIN")

# Emulator executables (absolute paths)
EXE_PATHS = {
    "cybergrime": str(DQ_ROOT / "cybergrime" / "psx_agent_runner.exe"),
    "duckstation": str(DQ_ROOT / "duckstation" / "duckstation-qt-x64-ReleaseLTCG.exe"),
    "starpsx": str(DQ_ROOT / "tools" / "starpsx" / "target" / "release" / "starpsx.exe"),
}

# DuckStation ini path (auto-configured per BIOS mode)
DUCKSTATION_INI = str(DQ_ROOT / "duckstation" / "duckstation-qt.ini")
DUCKSTATION_DIR = str(DQ_ROOT / "duckstation")

# ANSI color codes for terminal output
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    CYAN    = "\033[96m"
    MAGENTA = "\033[95m"
    GREY    = "\033[90m"

    @staticmethod
    def enabled() -> bool:
        return sys.stdout.isatty() and os.environ.get("NO_COLOR", "") == ""

# Emulator definitions: name -> executable path and argument conventions
# Cybergrime: psx_agent_runner.exe <disc.bin> <profile_name> [max_instrs] [json_path] [wallclock_ms] --bios <path> --verbose
# DuckStation: duckstation-qt-x64-ReleaseLTCG.exe -batch -nogui <disc.cue>  (BIOS via ini)
# StarPSX: starpsx.exe -a -f <disc.cue>  (BIOS via config.toml, auto-run + full-speed)
EMULATORS = {
    "cybergrime": {
        "exe_key": "cybergrime",
        "arg_style": "cybergrime",
    },
    "duckstation": {
        "exe_key": "duckstation",
        "arg_style": "duckstation",
    },
    "starpsx": {
        "exe_key": "starpsx",
        "arg_style": "starpsx",
    },
}

# BIOS mode definitions
BIOS_MODES = {
    "hle": {
        "label": "HLE (High-Level Emulation / fastboot)",
        "bios_path": None,
    },
    "vhb": {
        "label": "VHB Super BIOS",
        "bios_path_key": "vhb_bios",
    },
    "scph": {
        "label": "SCPH-1001 (Standard US)",
        "bios_path_key": "scph_bios",
    },
}


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

@dataclass
class TestResult:
    """Structured result for a single Emulator x BIOS x Disc test."""
    test_id: str
    emulator: str
    bios_mode: str
    disc: str
    bios_label: str
    bios_path: Optional[str]
    iso_path: str
    command: list
    start_time: str
    end_time: str
    duration_seconds: float
    exit_code: Optional[int]
    status: str  # "PASSED", "FAILED", "TIMEOUT_HANG"
    stdout_file: str
    stderr_file: str
    stdout_size_bytes: int
    stderr_size_bytes: int
    stdout_line_count: int
    stderr_line_count: int
    timeout_seconds: int
    error_message: Optional[str]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def utc_timestamp() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def c(color: str, text: str) -> str:
    """Wrap text in ANSI color if terminal supports it."""
    if C.enabled():
        return f"{color}{text}{C.RESET}"
    return text


def banner(text: str, char: str = "=", width: int = 76) -> None:
    line = char * width
    print()
    print(c(C.CYAN, line))
    print(c(C.CYAN + C.BOLD, f"  {text}"))
    print(c(C.CYAN, line))


def stage_header(stage_num: int, stage_name: str, width: int = 76) -> None:
    line = "-" * width
    label = f"  STAGE {stage_num}: {stage_name}"
    print()
    print(c(C.YELLOW + C.BOLD, line))
    print(c(C.YELLOW + C.BOLD, label))
    print(c(C.YELLOW + C.BOLD, line))


def status_badge(status: str) -> str:
    if status == "PASSED":
        return c(C.GREEN + C.BOLD, f"  PASSED  ")
    elif status == "TIMEOUT_HANG":
        return c(C.YELLOW + C.BOLD, f"  TIMEOUT ")
    else:
        return c(C.RED + C.BOLD, f"  FAILED  ")


def kill_process_tree(pid: int) -> None:
    """Forcefully kill a process and all its children on Windows."""
    try:
        subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            capture_output=True,
            timeout=5,
        )
    except Exception:
        pass


def build_command(
    emulator: str,
    bios_mode: str,
    disc_key: str,
    iso_path: str,
    vhb_bios: str,
    scph_bios: str,
    max_instr: int,
    log_dir: Path,
    test_id: str,
    extra_flags: dict = None,
) -> list:
    """Construct the CLI argument list for a given Emulator x BIOS x Disc test."""
    if extra_flags is None: extra_flags = {}
    cfg = EMULATORS[emulator]
    exe = EXE_PATHS[cfg["exe_key"]]
    style = cfg["arg_style"]
    bios_path = resolve_bios_path(bios_mode, vhb_bios, scph_bios)

    if style == "cybergrime":
        # psx_agent_runner.exe <disc.bin> <profile> [max_instrs] [json_path] --bios <path> --verbose
        # Cybergrime expects raw .bin, not .cue — convert .cue to .bin path
        if iso_path.lower().endswith(".cue"):
            cue_path = Path(iso_path)
            bin_name = None
            if cue_path.exists():
                with open(cue_path, "r") as f:
                    for line in f:
                        if line.strip().startswith("FILE"):
                            parts = line.split('"')
                            if len(parts) >= 3:
                                bin_name = parts[1]
                                break
            if bin_name:
                iso_path = str(cue_path.parent / bin_name)
            else:
                iso_path = iso_path[:-4] + ".bin"
        profile = test_id.replace("__", "_")
        telemetry_path = str(log_dir / f"{test_id}_cybergrime_telemetry.json")
        cmd = [exe, iso_path, profile, str(max_instr), telemetry_path, "0"]
        if bios_path:
            cmd.extend(["--bios", bios_path])
        if extra_flags.get("cg_trace_all"):
            cmd.append("--trace-all")
        if extra_flags.get("cg_break"):
            cmd.extend(["--break", extra_flags["cg_break"]])
        cmd.append("--verbose")
        return cmd

    elif style == "duckstation":
        # Verified per TESTING_QA_MANDATE_DQ4_Aug4_2026.md:
        # duckstation-qt-x64-ReleaseLTCG.exe -batch -earlyconsole <disc.cue>
        # BIOS path, region, FastBoot etc. are all in duckstation-qt.ini (auto-configured)
        cmd = [exe, "-batch", "-earlyconsole"]
        if bios_mode == "hle":
            cmd.append("-fastboot")
        else:
            cmd.append("-slowboot")
        cmd.append(iso_path)
        return cmd

    elif style == "starpsx":
        # starpsx.exe -a -f <disc.cue>
        # -a = auto-run (skip GUI), -f = full-speed
        # BIOS path is configured via config.toml (auto-configured before launch)
        cmd = [exe, "-a"]
        if not extra_flags.get("star_speed_limit"):
            cmd.append("-f")
        if extra_flags.get("star_debug"):
            cmd.append("-d")
        cmd.append(iso_path)
        return cmd

    return [exe]


def resolve_bios_path(
    bios_mode: str,
    vhb_bios: str,
    scph_bios: str,
) -> Optional[str]:
    if bios_mode == "vhb":
        return vhb_bios
    if bios_mode == "scph":
        return scph_bios
    return None


def configure_duckstation_ini(bios_mode: str, vhb_bios: str, scph_bios: str, extra_flags: dict = None) -> None:
    """Auto-configure duckstation-qt.ini for the given BIOS mode.
    DuckStation has almost no CLI flags — everything is ini-driven.
    This writes both root and settings/ ini files so agents never
    need to manually edit settings."""
    bios_path = resolve_bios_path(bios_mode, vhb_bios, scph_bios)

    if bios_mode == "hle":
        # HLE: FastBoot=true, no BIOS path, empty BIOSPath
        bios_path_ini = ""
        fast_boot = "true"
    else:
        # VHB or SCPH: FastBoot=false, explicit BIOS path
        bios_path_ini = bios_path.replace("\\", "/") if bios_path else ""
        fast_boot = "false"

    # BIOS directory = parent of the BIOS file
    if bios_path:
        bios_dir = str(Path(bios_path).parent).replace("\\", "/")
    else:
        bios_dir = str(DQ_ROOT / "bios" / "US").replace("\\", "/")

    if extra_flags is None: extra_flags = {}
    region = extra_flags.get("region", "NTSC_U")
    if region == "Auto": region = "Auto"
    ds_cpu = extra_flags.get("ds_cpu", "Recompiler")
    ds_gpu = extra_flags.get("ds_gpu", "Software")
    ds_speed = "true" if extra_flags.get("ds_speed_limit") else "false"

    ini_content = f"""[Directories]
BIOSDirectory={bios_dir}

[CPU]
ExecutionMode={ds_cpu}

[GPU]
Renderer={ds_gpu}

[Console]
Region={region}
Enable8MBRAM=false
BIOSPath={bios_path_ini}

[Logging]
LogLevel=Dev
LogToConsole=true
LogToFile=true
LogFileDir={DUCKSTATION_DIR.replace(chr(92), '/')}
LogFileName=ds_harness.log

[Emulator]
FastBoot={fast_boot}
SpeedLimiterEnabled={ds_speed}
"""
    # Write to both ini locations: root and settings/
    ini_paths = [
        DUCKSTATION_INI,
        str(Path(DUCKSTATION_DIR) / "settings" / "duckstation-qt.ini"),
    ]
    for ini_path in ini_paths:
        Path(ini_path).parent.mkdir(parents=True, exist_ok=True)
        with open(ini_path, "w", encoding="utf-8") as f:
            f.write(ini_content)


def configure_starpsx_config(bios_mode: str, vhb_bios: str, scph_bios: str, extra_flags: dict = None) -> None:
    """Auto-configure StarPSX config.toml for the given BIOS mode.
    StarPSX reads BIOS path from %APPDATA%/StarPSX/config.toml.
    For HLE mode, we omit bios_path (StarPSX has no HLE — it always
    requires a BIOS, so we use SCPH-1001 as the default for HLE tests)."""
    bios_path = resolve_bios_path(bios_mode, vhb_bios, scph_bios)
    # StarPSX has no HLE mode — always needs a BIOS file
    if bios_path is None:
        bios_path = scph_bios  # Use SCPH-1001 as fallback for "HLE" mode

    config_dir = Path(os.environ.get("APPDATA", "")) / "StarPSX"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.toml"

    # Escape backslashes for TOML string
    bios_path_escaped = bios_path.replace("\\", "\\\\")

    config_content = f'bios_path = "{bios_path_escaped}"\n'
    with open(config_path, "w", encoding="utf-8") as f:
        f.write(config_content)


# ---------------------------------------------------------------------------
# Stream Reader (tee subprocess output to console + file)
# ---------------------------------------------------------------------------

class StreamTee:
    """Reads a subprocess pipe line-by-line, writes to file and prints to console."""

    def __init__(
        self,
        pipe,
        file_handle,
        prefix: str,
        color: str,
        max_lines: int,
        quiet: bool,
    ):
        self.pipe = pipe
        self.file_handle = file_handle
        self.prefix = prefix
        self.color = color
        self.max_lines = max_lines  # 0 = unlimited
        self.quiet = quiet
        self.line_count = 0
        self.truncated = False
        self._lock = threading.Lock()

    def read_loop(self) -> None:
        try:
            for raw_line in self.pipe:
                line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
                with self._lock:
                    self.line_count += 1
                    self.file_handle.write(line + "\n")
                    self.file_handle.flush()

                    if not self.quiet:
                        if self.max_lines == 0 or self.line_count <= self.max_lines:
                            tag = c(self.color, f"{self.prefix}")
                            print(f"  {tag} {line}")
                        elif not self.truncated:
                            self.truncated = True
                            print(c(C.GREY, f"  {self.prefix} ... (output truncated, see log for full output)"))
        except Exception:
            pass
        finally:
            try:
                self.pipe.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Core Test Runner
# ---------------------------------------------------------------------------

def run_test(
    test_id: str,
    emulator: str,
    bios_mode: str,
    disc_key: str,
    iso_path: str,
    vhb_bios: str,
    scph_bios: str,
    max_instr: int,
    timeout: int,
    log_dir: Path,
    max_output_lines: int,
    quiet: bool,
    extra_flags: dict = None,
) -> TestResult:
    """Execute a single test node and return structured results."""
    if extra_flags is None: extra_flags = {}
    cfg = EMULATORS[emulator]
    exe = EXE_PATHS[cfg["exe_key"]]
    bios_path = resolve_bios_path(bios_mode, vhb_bios, scph_bios)
    bios_label = BIOS_MODES[bios_mode]["label"]

    # Auto-configure emulator configs before launch
    if emulator == "duckstation":
        configure_duckstation_ini(bios_mode, vhb_bios, scph_bios, extra_flags)
    elif emulator == "starpsx":
        configure_starpsx_config(bios_mode, vhb_bios, scph_bios, extra_flags)

    cmd = build_command(
        emulator, bios_mode, disc_key, iso_path,
        vhb_bios, scph_bios, max_instr, log_dir, test_id, extra_flags,
    )

    # Apply per-emulator timeout multiplier
    effective_timeout = int(timeout * EMULATOR_TIMEOUT_MULT.get(emulator, 1.0))

    stdout_file = log_dir / f"{test_id}_stdout.txt"
    stderr_file = log_dir / f"{test_id}_stderr.txt"
    telemetry_file = log_dir / f"{test_id}_telemetry.json"

    start_ts = utc_timestamp()
    start_perf = time.perf_counter()

    status = "FAILED"
    exit_code: Optional[int] = None
    error_message: Optional[str] = None
    stdout_line_count = 0
    stderr_line_count = 0

    # Test header
    print()
    print(c(C.BLUE, f"  +{'-' * 74}+"))
    print(c(C.BLUE + C.BOLD, f"  | {test_id:<42} {emulator:<16} {bios_mode:<12} |"))
    print(c(C.BLUE, f"  +{'-' * 74}+"))
    print(c(C.GREY, f"  CMD: {' '.join(cmd)}"))
    print(c(C.GREY, f"  LOG: {stdout_file.name} / {stderr_file.name}"))
    print()

    # Working directory = emulator's directory (for DLLs, configs, etc.)
    cwd = str(Path(exe).parent)

    # All emulators use piped stdout/stderr.
    # StarPSX is GUI-based (egui) but handles piped output correctly.
    creation_flags = 0
    if sys.platform == "win32":
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP

    try:
        with open(stdout_file, "w", encoding="utf-8") as f_out, \
             open(stderr_file, "w", encoding="utf-8") as f_err:

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=cwd,
                creationflags=creation_flags,
            )

            # Start tee reader threads
            stdout_reader = StreamTee(
                proc.stdout, f_out, "[OUT]", C.GREEN, max_output_lines, quiet,
            )
            stderr_reader = StreamTee(
                proc.stderr, f_err, "[ERR]", C.RED, max_output_lines, quiet,
            )

            t_out = threading.Thread(target=stdout_reader.read_loop, daemon=True)
            t_err = threading.Thread(target=stderr_reader.read_loop, daemon=True)
            t_out.start()
            t_err.start()

            # Wait with timeout
            try:
                exit_code = proc.wait(timeout=effective_timeout)
                # Cybergrime exit codes: 0=clean, 1=boot_fail (still valid telemetry),
                # 2=usage error. Treat 0 and 1 as COMPLETED (not FAILED).
                if emulator == "cybergrime" and exit_code in (0, 1):
                    status = "PASSED"
                elif exit_code == 0:
                    status = "PASSED"
                else:
                    status = "FAILED"
            except subprocess.TimeoutExpired:
                kill_process_tree(proc.pid)
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    pass
                status = "TIMEOUT_HANG"
                exit_code = None
                error_message = f"Process did not exit within {effective_timeout}s - killed."
                print(c(C.YELLOW + C.BOLD, f"  >>> TIMEOUT after {effective_timeout}s - killing process tree..."))

            # Wait for reader threads to drain pipes
            t_out.join(timeout=2)
            t_err.join(timeout=2)

            stdout_line_count = stdout_reader.line_count
            stderr_line_count = stderr_reader.line_count

    except FileNotFoundError:
        status = "FAILED"
        exit_code = -1
        error_message = f"Executable not found: {exe}"
        with open(stderr_file, "w") as f:
            f.write(error_message + "\n")
        stderr_line_count = 1
        print(c(C.RED + C.BOLD, f"  >>> {error_message}"))
    except Exception as exc:
        status = "FAILED"
        exit_code = -2
        error_message = f"Exception: {exc}"
        with open(stderr_file, "w") as f:
            f.write(error_message + "\n")
        stderr_line_count = 1
        print(c(C.RED + C.BOLD, f"  >>> {error_message}"))

    end_perf = time.perf_counter()
    duration = round(end_perf - start_perf, 3)
    end_ts = utc_timestamp()

    stdout_size = stdout_file.stat().st_size if stdout_file.exists() else 0
    stderr_size = stderr_file.stat().st_size if stderr_file.exists() else 0

    # Result line
    print()
    badge = status_badge(status)
    print(f"  {badge}  exit={exit_code}  duration={duration:.3f}s  out={stdout_line_count}L  err={stderr_line_count}L")
    print(c(C.GREY, f"  telemetry: {telemetry_file.name}"))
    print()

    result = TestResult(
        test_id=test_id,
        emulator=emulator,
        bios_mode=bios_mode,
        disc=disc_key,
        bios_label=bios_label,
        bios_path=bios_path,
        iso_path=iso_path,
        command=cmd,
        start_time=start_ts,
        end_time=end_ts,
        duration_seconds=duration,
        exit_code=exit_code,
        status=status,
        stdout_file=str(stdout_file),
        stderr_file=str(stderr_file),
        stdout_size_bytes=stdout_size,
        stderr_size_bytes=stderr_size,
        stdout_line_count=stdout_line_count,
        stderr_line_count=stderr_line_count,
        timeout_seconds=timeout,
        error_message=error_message,
    )

    with open(telemetry_file, "w", encoding="utf-8") as f:
        json.dump(asdict(result), f, indent=2)

    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description="PSX Multi-Emulator x Multi-BIOS Test Matrix Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--timeout", type=int, default=DEFAULT_TIMEOUT,
        help=f"Per-test timeout in seconds (default: {DEFAULT_TIMEOUT})",
    )
    parser.add_argument(
        "--disc", type=str, choices=list(DISCS.keys()), action="append",
        help="Disc to test: frankenstein or dw7 (repeatable, default: frankenstein only)",
    )
    parser.add_argument(
        "--iso", type=str, default=None,
        help="Explicit path to disc .cue (overrides --disc)",
    )
    parser.add_argument(
        "--vhb-bios", type=str, default=DEFAULT_VHB_BIOS,
        help="Path to VHB Super BIOS",
    )
    parser.add_argument(
        "--scph-bios", type=str, default=DEFAULT_SCPH_BIOS,
        help="Path to SCPH-1001 BIOS",
    )
    parser.add_argument(
        "--log-dir", type=str, default=DEFAULT_LOG_DIR,
        help="Output directory for logs",
    )
    parser.add_argument(
        "--emulator", type=str, choices=list(EMULATORS.keys()),
        help="Run only one emulator",
    )
    parser.add_argument(
        "--bios-mode", type=str, choices=list(BIOS_MODES.keys()),
        help="Run only one BIOS mode",
    )
    parser.add_argument(
        "--max-instr", type=int, default=DEFAULT_MAX_INSTR,
        help=f"Max instructions for Cybergrime (default: {DEFAULT_MAX_INSTR})",
    )
    parser.add_argument(
        "--max-output-lines", type=int, default=DEFAULT_MAX_OUTPUT_LINES,
        help=f"Max lines of live output per test (0=unlimited, default: {DEFAULT_MAX_OUTPUT_LINES})",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print commands without executing",
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Clear log directory before running",
    )
    parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress live emulator output (show status badges only)",
    )
    parser.add_argument(
        "--no-color", action="store_true",
        help="Disable ANSI color output (for piped/agent use)",
    )
    parser.add_argument(
        "--fail-fast", action="store_true",
        help="Stop on first FAILED or TIMEOUT_HANG test",
    )
    parser.add_argument(
        "--tag", type=str, default=None,
        help="Tag for this matrix run (embedded in summary JSON)",
    )
    parser.add_argument(
        "--smoke-test", action="store_true",
        help="Quick validation: run DW7 + all emulators + all BIOS modes with short timeout",
    )
    parser.add_argument(
        "--report", action="store_true",
        help="Generate BIOS-side and ROM-side reports from telemetry after run",
    )
    parser.add_argument(
        "--wallclock-ms", type=int, default=0,
        help="Wall clock limit in ms for Cybergrime (0=no limit, default: 0)",
    )
    # Per-emulator convenience flags (mutually exclusive with --emulator)
    parser.add_argument(
        "--cybergrime-only", action="store_true",
        help="Run only Cybergrime tests (shortcut for --emulator cybergrime)",
    )
    parser.add_argument(
        "--duckstation-only", action="store_true",
        help="Run only DuckStation tests (shortcut for --emulator duckstation)",
    )
    parser.add_argument(
        "--starpsx-only", action="store_true",
        help="Run only StarPSX tests (shortcut for --emulator starpsx)",
    )
    # Per-BIOS convenience flags
    parser.add_argument(
        "--hle-only", action="store_true",
        help="Run only HLE BIOS mode tests (shortcut for --bios-mode hle)",
    )
    parser.add_argument(
        "--vhb-only", action="store_true",
        help="Run only VHB Super BIOS mode tests (shortcut for --bios-mode vhb)",
    )
    parser.add_argument(
        "--scph-only", action="store_true",
        help="Run only SCPH-1001 BIOS mode tests (shortcut for --bios-mode scph)",
    )
    parser.add_argument(
        "--region", type=str, default="NTSC_U",
        choices=["Auto", "NTSC_U", "NTSC_J", "PAL"],
        help="Console region for DuckStation"
    )
    parser.add_argument(
        "--ds-cpu", type=str, default="Recompiler",
        choices=["Recompiler", "Interpreter"],
        help="DuckStation CPU Execution Mode"
    )
    parser.add_argument(
        "--ds-gpu", type=str, default="Software",
        choices=["Software", "Hardware", "Vulkan", "D3D11", "D3D12"],
        help="DuckStation GPU Renderer"
    )
    parser.add_argument(
        "--ds-speed-limit", action="store_true",
        help="Enable DuckStation speed limiter"
    )
    parser.add_argument(
        "--cg-trace-all", action="store_true",
        help="Enable full instruction trace in CyberGrime"
    )
    parser.add_argument(
        "--cg-break", type=str, default=None,
        help="Hard hardware breakpoint address for CyberGrime (e.g. 0x8004F344)"
    )
    parser.add_argument(
        "--star-debug", action="store_true",
        help="Enable StarPSX debug mode"
    )
    parser.add_argument(
        "--star-speed-limit", action="store_true",
        help="Enable StarPSX speed limiter"
    )
    args = parser.parse_args()

    # Handle --no-color by setting env var (C.enabled() checks it)
    if args.no_color:
        os.environ["NO_COLOR"] = "1"

    # Smoke-test mode: DW7 + all emulators + all BIOS + short timeout
    if args.smoke_test:
        discs_to_run = {"dw7": DISCS["dw7"]}
        effective_timeout = 30
        smoke_max_instr = 1_000_000
    elif args.iso:
        discs_to_run = {"custom": {"label": "Custom ISO", "cue": args.iso}}
        effective_timeout = args.timeout
        smoke_max_instr = args.max_instr
    elif args.disc:
        discs_to_run = {d: DISCS[d] for d in args.disc}
        effective_timeout = args.timeout
        smoke_max_instr = args.max_instr
    else:
        discs_to_run = {"v99": DISCS["v99"]}
        effective_timeout = args.timeout
        smoke_max_instr = args.max_instr

    # Determine emulator set from --emulator or convenience flags
    if args.cybergrime_only:
        emulators_to_run = ["cybergrime"]
    elif args.duckstation_only:
        emulators_to_run = ["duckstation"]
    elif args.starpsx_only:
        emulators_to_run = ["starpsx"]
    elif args.emulator:
        emulators_to_run = [args.emulator]
    else:
        emulators_to_run = list(EMULATORS.keys())

    # Determine BIOS mode set from --bios-mode or convenience flags
    if args.hle_only:
        bios_modes_to_run = ["hle"]
    elif args.vhb_only:
        bios_modes_to_run = ["vhb"]
    elif args.scph_only:
        bios_modes_to_run = ["scph"]
    elif args.bios_mode:
        bios_modes_to_run = [args.bios_mode]
    else:
        bios_modes_to_run = list(BIOS_MODES.keys())

    # Build test list: (test_id, emulator, bios_mode, disc_key, iso_path)
    tests = []
    for disc_key, disc_info in discs_to_run.items():
        for emu in emulators_to_run:
            for bios in bios_modes_to_run:
                # StarPSX does not support HLE mode
                if emu == "starpsx" and bios == "hle":
                    continue
                tid = f"{disc_key}__{emu}__{bios}"
                tests.append((tid, emu, bios, disc_key, disc_info["cue"]))

    total = len(tests)
    log_dir = Path(args.log_dir)

    # Header
    banner("PSX META-HARNESS -- Multi-Emulator x Multi-BIOS Test Matrix")
    print(f"  {c(C.DIM, 'Emulators:')}   {', '.join(emulators_to_run)}")
    print(f"  {c(C.DIM, 'BIOS modes:')}  {', '.join(bios_modes_to_run)}")
    print(f"  {c(C.DIM, 'Discs:')}       {', '.join(discs_to_run.keys())}")
    print(f"  {c(C.DIM, 'Total tests:')} {total}")
    print(f"  {c(C.DIM, 'Timeout:')}     {effective_timeout}s per test")
    for dk, di in discs_to_run.items():
        print(f"  {c(C.DIM, f'  {dk}:')}      {di['cue']}")
    print(f"  {c(C.DIM, 'VHB BIOS:')}    {args.vhb_bios}")
    print(f"  {c(C.DIM, 'SCPH BIOS:')}   {args.scph_bios}")
    print(f"  {c(C.DIM, 'Log dir:')}     {log_dir}")
    print(f"  {c(C.DIM, 'Live output:')} {'suppressed (--quiet)' if args.quiet else f'max {args.max_output_lines} lines/test'}")
    if args.tag:
        print(f"  {c(C.DIM, 'Tag:')}         {args.tag}")
    if args.fail_fast:
        print(f"  {c(C.DIM, 'Fail-fast:')}   enabled")

    # Dry-run: print commands only
    if args.dry_run:
        stage_header(1, "DRY RUN -- Command Preview")
        for i, (test_id, emu, bios, disc_key, iso_path) in enumerate(tests, 1):
            # For dry-run, we need a temp log_dir for command building
            cmd = build_command(
                emu, bios, disc_key, iso_path,
                args.vhb_bios, args.scph_bios, smoke_max_instr, log_dir, test_id,
            )
            print(f"  [{i}/{total}] {test_id}")
            print(f"    $ {' '.join(cmd)}")
            print()
        print("Dry run complete - no tests executed.")
        return 0

    # Clean log directory if requested
    if args.clean and log_dir.exists():
        def _on_rmtree_error(func, path, exc_info):
            try:
                os.chmod(path, 0o777)
                func(path)
            except Exception:
                pass  # Skip locked files
        shutil.rmtree(log_dir, onerror=_on_rmtree_error)
    log_dir.mkdir(parents=True, exist_ok=True)

    # Stage 1: Pre-flight checks
    stage_header(1, "PRE-FLIGHT CHECKS")
    preflight_ok = True
    for disc_key, disc_info in discs_to_run.items():
        if not Path(disc_info["cue"]).exists():
            print(f"  {c(C.YELLOW, 'WARNING')}: {disc_key} disc not found: {disc_info['cue']}")
            preflight_ok = False
    if not Path(args.vhb_bios).exists():
        print(f"  {c(C.YELLOW, 'WARNING')}: VHB BIOS not found: {args.vhb_bios}")
        preflight_ok = False
    if not Path(args.scph_bios).exists():
        print(f"  {c(C.YELLOW, 'WARNING')}: SCPH BIOS not found: {args.scph_bios}")
        preflight_ok = False
    for emu in emulators_to_run:
        exe = EXE_PATHS[EMULATORS[emu]["exe_key"]]
        if not Path(exe).exists():
            print(f"  {c(C.YELLOW, 'WARNING')}: {emu} executable not found: {exe}")
            preflight_ok = False
    if preflight_ok:
        print(f"  {c(C.GREEN, 'OK')} All pre-flight checks passed.")
    else:
        print(f"  {c(C.YELLOW, 'NOTE')} Some assets missing - tests for missing items will fail.")

    # Stage 2: Execute test matrix
    stage_header(2, f"EXECUTE TEST MATRIX ({total} tests)")
    results: list[TestResult] = []
    matrix_start = time.perf_counter()

    for i, (test_id, emu, bios, disc_key, iso_path) in enumerate(tests, 1):
        print(c(C.CYAN + C.BOLD, f"  -- Test {i}/{total} -----------------------------------------------"))
        result = run_test(
            test_id=test_id,
            emulator=emu,
            bios_mode=bios,
            disc_key=disc_key,
            iso_path=iso_path,
            vhb_bios=args.vhb_bios,
            scph_bios=args.scph_bios,
            max_instr=smoke_max_instr,
            timeout=effective_timeout,
            log_dir=log_dir,
            max_output_lines=args.max_output_lines,
            quiet=args.quiet,
            extra_flags={
                "region": args.region,
                "ds_cpu": args.ds_cpu,
                "ds_gpu": args.ds_gpu,
                "ds_speed_limit": args.ds_speed_limit,
                "cg_trace_all": args.cg_trace_all,
                "cg_break": args.cg_break,
                "star_debug": args.star_debug,
                "star_speed_limit": args.star_speed_limit,
            },
        )
        results.append(result)

        # Fail-fast: stop on first non-PASS
        if args.fail_fast and result.status != "PASSED":
            print(c(C.RED + C.BOLD, f"  >>> FAIL-FAST: stopping after {len(results)} test(s) — {result.status}"))
            break

    matrix_end = time.perf_counter()
    total_duration = round(matrix_end - matrix_start, 3)

    # Aggregate
    passed = sum(1 for r in results if r.status == "PASSED")
    failed = sum(1 for r in results if r.status == "FAILED")
    timeout_hang = sum(1 for r in results if r.status == "TIMEOUT_HANG")

    summary = {
        "matrix_run_id": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
        "tag": args.tag,
        "run_start_time": results[0].start_time if results else utc_timestamp(),
        "run_end_time": results[-1].end_time if results else utc_timestamp(),
        "total_duration_seconds": total_duration,
        "configuration": {
            "timeout_seconds": effective_timeout,
            "discs": list(discs_to_run.keys()),
            "vhb_bios_path": args.vhb_bios,
            "scph_bios_path": args.scph_bios,
            "max_instr": smoke_max_instr,
            "emulators": emulators_to_run,
            "bios_modes": bios_modes_to_run,
            "extra_flags": {
                "region": args.region,
                "ds_cpu": args.ds_cpu,
                "ds_gpu": args.ds_gpu,
                "ds_speed_limit": args.ds_speed_limit,
                "cg_trace_all": args.cg_trace_all,
                "cg_break": args.cg_break,
                "star_debug": args.star_debug,
                "star_speed_limit": args.star_speed_limit,
            },
        },
        "summary": {
            "total_tests": total,
            "passed": passed,
            "failed": failed,
            "timeout_hang": timeout_hang,
        },
        "results": [asdict(r) for r in results],
    }

    summary_file = PROJECT_ROOT / "matrix_summary.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    # Stage 3: Final report
    stage_header(3, "MATRIX RESULTS")

    print()
    print(f"  {c(C.GREEN + C.BOLD, str(passed))} PASSED   "
          f"{c(C.RED + C.BOLD, str(failed))} FAILED   "
          f"{c(C.YELLOW + C.BOLD, str(timeout_hang))} TIMEOUT_HANG")
    print(f"  Total duration: {total_duration}s")
    print(f"  Summary file:   {summary_file}")
    print(f"  Log directory:  {log_dir}")
    print()

    # Results table
    print(f"  {'Test ID':<40} {'Status':<15} {'Exit':<8} {'Duration':<12} {'Out':<8} {'Err'}")
    print(f"  {'-' * 40} {'-' * 15} {'-' * 8} {'-' * 12} {'-' * 8} {'-' * 6}")
    for r in results:
        badge = status_badge(r.status).strip()
        print(
            f"  {r.test_id:<40} {badge:<15} "
            f"{str(r.exit_code):<8} {r.duration_seconds:.3f}s{'':<5} "
            f"{r.stdout_line_count:<8} {r.stderr_line_count}"
        )
    print()

    return 0 if passed > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
