#!/usr/bin/env python3
"""
hydra_loop.py - PSX MATRIX HYDRA: Autonomous Build/Test/Debug Loop

Orchestrates the 4-phase Hydra Loop:
  Phase 1: Build (CyberGrime) - compile C++ builder + generate disc
  Phase 2: Matrix Execution (PSXMatrix) - multi-emulator test matrix
  Phase 3: Telemetry Analysis (Digital Twin) - correlate static/dynamic
  Phase 4: Hypothesis & Refinement - output diagnosis + recommendations

The loop runs iteratively until the disc boots (G2-PASS with GPU active)
or max iterations are reached.

Usage:
    python hydra_loop.py                          # Full loop (build + test + analyze)
    python hydra_loop.py --max-iterations 5       # Limit iterations
    python hydra_loop.py --build-only             # Just build, skip matrix
    python hydra_loop.py --test-only              # Just test existing disc + analyze
    python hydra_loop.py --smoke-test             # Quick 30s matrix validation
    python hydra_loop.py --no-color               # Clean output for agents
    python hydra_loop.py --fail-fast              # Stop on first non-PASS
"""

import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
DQ_ROOT = Path(r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION")
CYBER_DIR = DQ_ROOT / "cybergrime"
PSXMATRIX_DIR = DQ_ROOT / "PSXMatrix"
STAGING_DIR = DQ_ROOT / "build_staging"
OUTPUT_BIN = STAGING_DIR / "dq4_frankenstein_v99.bin"
OUTPUT_CUE = STAGING_DIR / "dq4_frankenstein_v99.cue"
BUILD_LOG = STAGING_DIR / "build_output.log"
HYDRA_LOG_DIR = STAGING_DIR / "hydra_logs"

# Emulator/BIOS paths
DUCK_EXE = DQ_ROOT / "duckstation" / "duckstation-qt-x64-ReleaseLTCG.exe"
VHB_BIOS = DQ_ROOT / "VHB_SUPER_BIOS_V1.00A" / "FRANKENSTEIN.BIOS"
SCPH_BIOS = DQ_ROOT / "bios" / "US" / "SCPH1001.BIN"

# ---------------------------------------------------------------------------
# ANSI Colors
# ---------------------------------------------------------------------------
class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    MAGENTA = "\033[95m"
    GREY = "\033[90m"

    @staticmethod
    def enabled() -> bool:
        return sys.stdout.isatty() and os.environ.get("NO_COLOR", "") == ""


def c(color: str, text: str) -> str:
    if C.enabled():
        return f"{color}{text}{C.RESET}"
    return text


def banner(text: str, char: str = "=", width: int = 76) -> None:
    line = char * width
    print()
    print(c(C.CYAN, line))
    print(c(C.CYAN + C.BOLD, f"  {text}"))
    print(c(C.CYAN, line))


def phase_header(phase_num: int, phase_name: str, iteration: int, width: int = 76) -> None:
    line = "-" * width
    label = f"  PHASE {phase_num}: {phase_name}  [Iteration {iteration}]"
    print()
    print(c(C.YELLOW + C.BOLD, line))
    print(c(C.YELLOW + C.BOLD, label))
    print(c(C.YELLOW + C.BOLD, line))


def utc_timestamp() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run(cmd, cwd=None, timeout=300, capture=True):
    """Run a command, return (success, output)."""
    cmd_str = " ".join(str(s) for s in cmd)
    print(f"  $ {cmd_str}")
    try:
        r = subprocess.run(
            cmd, cwd=str(cwd) if cwd else None,
            capture_output=capture, text=True, timeout=timeout,
            shell=False,
        )
        if r.returncode != 0 and capture:
            lines = (r.stderr or r.stdout or "").strip().split("\n")
            for line in lines[-15:]:
                print(f"    {line}")
        return r.returncode == 0, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        print(c(C.RED, "  TIMEOUT"))
        return False, "TIMEOUT"
    except Exception as e:
        print(f"  ERROR: {e}")
        return False, str(e)


# ---------------------------------------------------------------------------
# Phase 1: Build (CyberGrime)
# ---------------------------------------------------------------------------

def phase1_build(iteration: int, build_only: bool = False, hotfixes: str = None) -> dict:
    """Compile C++ builder and generate disc image."""
    phase_header(1, "BUILD (CyberGrime)", iteration)

    result = {
        "phase": "build",
        "iteration": iteration,
        "timestamp": utc_timestamp(),
        "compile_success": False,
        "disc_success": False,
        "disc_path": "",
        "disc_size": 0,
        "build_log": "",
        "patches": {},
    }

    # Step 1a: Compile frankenstein_build.exe
    print(c(C.CYAN, "  [1a] Compiling C++ canonical builder..."))
    ok, compile_output = run([
        "g++", "-std=c++17", "-O2", "-o", "frankenstein_build.exe",
        "frankenstein_build_main.cpp", "psx_binary_ops.cpp", "-lpsapi"
    ], cwd=CYBER_DIR, timeout=120)

    if not ok:
        print(c(C.RED + C.BOLD, "  COMPILE FAILED"))
        result["compile_success"] = False
        return result

    result["compile_success"] = True
    print(c(C.GREEN, "  Compile: OK"))

    # Step 1b: Build disc via pipeline.py --build-only
    print(c(C.CYAN, "  [1b] Building disc image..."))
    build_cmd = [sys.executable, "pipeline.py", "--build-only"]
    if hotfixes:
        build_cmd.extend(["--hotfixes", str(Path(hotfixes).resolve())])
    ok, build_output = run(build_cmd, cwd=DQ_ROOT, timeout=600)

    # Save build log for Digital Twin
    HYDRA_LOG_DIR.mkdir(parents=True, exist_ok=True)
    build_log_path = HYDRA_LOG_DIR / f"iter{iteration}_build.log"
    with open(build_log_path, "w", encoding="utf-8") as f:
        f.write(build_output)
    result["build_log"] = str(build_log_path)

    # Also write to the expected path for digital_twin.py
    with open(BUILD_LOG, "w", encoding="utf-8") as f:
        f.write(build_output)

    if not ok and not OUTPUT_BIN.exists():
        print(c(C.RED + C.BOLD, "  DISC BUILD FAILED"))
        result["disc_success"] = False
        return result

    if OUTPUT_BIN.exists() and OUTPUT_BIN.stat().st_size > 350 * 1024 * 1024:
        result["disc_success"] = True
        result["disc_path"] = str(OUTPUT_BIN)
        result["disc_size"] = OUTPUT_BIN.stat().st_size
        print(c(C.GREEN, f"  Disc: {OUTPUT_BIN.name} ({result['disc_size'] / (1024*1024):.1f} MB)"))

        # Parse patch summary from build output
        for line in build_output.split("\n"):
            if "Patches:" in line:
                print(f"  {line.strip()}")
                # Parse: Patches: tree=24 disc=3 lba=1 seq=44 trampoline=2
                parts = line.split()
                for part in parts[1:]:
                    if "=" in part:
                        k, v = part.split("=", 1)
                        try:
                            result["patches"][k] = int(v.split("(")[0])
                        except ValueError:
                            pass
                break
            for kw in ["EXE:", "PC0:", "HBD:", "BUILD COMPLETE"]:
                if kw in line:
                    print(f"  {line.strip()}")
                    break

        # Step 1c: Automated ISO Static Verification Gate
        try:
            if str(DQ_ROOT) not in sys.path:
                sys.path.insert(0, str(DQ_ROOT))
            from verify import twin_phase1_static
            static_log = HYDRA_LOG_DIR / f"iter{iteration}_static_analysis.json"
            static_res = twin_phase1_static.run_phase1(str(OUTPUT_BIN), str(build_log_path), str(static_log))
            result["static_qa"] = static_res.get("binary_analysis", {})
            if static_res.get("binary_analysis", {}).get("all_patches_pass"):
                print(c(C.GREEN, "  Static ISO QA: PASS (12/12 Patches & ISO Structure Verified)"))
            else:
                print(c(C.YELLOW, "  Static ISO QA: WARNING (Static Verification Flags Reported)"))
        except Exception as e:
            print(c(C.YELLOW, f"  Static ISO QA: Skipped ({e})"))
    else:
        print(c(C.RED + C.BOLD, "  DISC BUILD FAILED (no output)"))
        result["disc_success"] = False

    return result


# ---------------------------------------------------------------------------
# Phase 2: Matrix Execution (PSXMatrix)
# ---------------------------------------------------------------------------

def phase2_matrix(iteration: int, smoke_test: bool = False,
                  fail_fast: bool = False, timeout: int = 60,
                  emulator: str = None, bios_mode: str = None,
                  multi_emulator: bool = False,
                  extra_flags: dict = None) -> dict:
    """Run PSXMatrix meta-harness against the built disc."""
    if extra_flags is None: extra_flags = {}
    phase_header(2, "MATRIX EXECUTION (PSXMatrix)", iteration)

    result = {
        "phase": "matrix",
        "iteration": iteration,
        "timestamp": utc_timestamp(),
        "matrix_success": False,
        "summary_path": "",
        "log_dir": "",
        "total_tests": 0,
        "passed": 0,
        "failed": 0,
        "timeout_hang": 0,
    }

    # Build meta-harness command
    cmd = [
        sys.executable, "meta_harness.py",
        "--iso", str(OUTPUT_CUE),
        "--no-color",
        "--clean",
    ]

    if smoke_test:
        cmd.append("--smoke-test")
        cmd.extend(["--timeout", "30"])
    else:
        cmd.extend(["--timeout", str(timeout)])

    if fail_fast:
        cmd.append("--fail-fast")

    if not multi_emulator and not emulator:
        emulator = "duckstation"

    if emulator:
        cmd.extend(["--emulator", emulator])
    if bios_mode:
        cmd.extend(["--bios-mode", bios_mode])

    # Add extra flags for meta_harness
    if extra_flags.get("region"): cmd.extend(["--region", extra_flags["region"]])
    if extra_flags.get("ds_cpu"): cmd.extend(["--ds-cpu", extra_flags["ds_cpu"]])
    if extra_flags.get("ds_gpu"): cmd.extend(["--ds-gpu", extra_flags["ds_gpu"]])
    if extra_flags.get("ds_speed_limit"): cmd.append("--ds-speed-limit")
    if extra_flags.get("cg_trace_all"): cmd.append("--cg-trace-all")
    if extra_flags.get("cg_break"): cmd.extend(["--cg-break", extra_flags["cg_break"]])
    if extra_flags.get("star_debug"): cmd.append("--star-debug")
    if extra_flags.get("star_speed_limit"): cmd.append("--star-speed-limit")

    cmd.extend(["--tag", f"hydra_iteration_{iteration}"])

    print(c(C.CYAN, f"  [2] Running PSXMatrix meta-harness..."))
    ok, output = run(cmd, cwd=PSXMATRIX_DIR, timeout=600)

    result["matrix_success"] = ok
    result["summary_path"] = str(PSXMATRIX_DIR / "matrix_summary.json")
    result["log_dir"] = str(PSXMATRIX_DIR / "matrix_logs")

    # Save matrix output
    matrix_log_path = HYDRA_LOG_DIR / f"iter{iteration}_matrix.log"
    with open(matrix_log_path, "w", encoding="utf-8") as f:
        f.write(output)

    # Parse summary
    summary_path = PSXMATRIX_DIR / "matrix_summary.json"
    if summary_path.exists():
        try:
            with open(summary_path, "r") as f:
                summary = json.load(f)
            s = summary.get("summary", {})
            result["total_tests"] = s.get("total_tests", 0)
            result["passed"] = s.get("passed", 0)
            result["failed"] = s.get("failed", 0)
            result["timeout_hang"] = s.get("timeout_hang", 0)
            print(f"  Matrix: {result['passed']} passed, {result['failed']} failed, "
                  f"{result['timeout_hang']} timeout")
        except (json.JSONDecodeError, OSError):
            pass

    # Also run analyze_telemetry.py for per-test diagnostics
    print(c(C.CYAN, f"  [2b] Running telemetry analysis..."))
    analyze_cmd = [
        sys.executable, "analyze_telemetry.py",
        "--no-color", "--json",
    ]
    run(analyze_cmd, cwd=PSXMATRIX_DIR, timeout=60)

    return result


# ---------------------------------------------------------------------------
# Phase 3: Telemetry Analysis (Digital Twin)
# ---------------------------------------------------------------------------

def phase3_analysis(iteration: int, build_log_path: str,
                    matrix_summary_path: str, log_dir: str) -> dict:
    """Run Digital Twin correlation engine."""
    phase_header(3, "TELEMETRY ANALYSIS (Digital Twin)", iteration)

    result = {
        "phase": "analysis",
        "iteration": iteration,
        "timestamp": utc_timestamp(),
        "diagnosis": None,
        "failure_mode": "UNKNOWN",
        "overall_status": "UNKNOWN",
    }

    # Import and run phased digital_twin directly
    VERIFY_DIR = DQ_ROOT / "verify"
    sys.path.insert(0, str(VERIFY_DIR))
    try:
        import run_digital_twin
    except ImportError as e:
        print(c(C.RED, f"  Cannot import run_digital_twin: {e}"))
        return result

    print(c(C.CYAN, f"  [3] Correlating static patches with dynamic telemetry..."))
    res_phases = run_digital_twin.run_all_phases(
        build_log_path=build_log_path,
        matrix_summary_path=matrix_summary_path,
        root_dir=str(DQ_ROOT),
    )
    p4 = res_phases.get("phase4", {})

    diag_path = HYDRA_LOG_DIR / f"iter{iteration}_diagnosis.json"
    with open(diag_path, "w", encoding="utf-8") as f:
        json.dump(p4, f, indent=2, ensure_ascii=False)

    result["diagnosis"] = p4
    result["failure_mode"] = p4.get("failure_mode", "UNKNOWN")
    result["overall_status"] = p4.get("failure_mode", "UNKNOWN")

    print(f"  Failure mode:       {p4.get('failure_mode')}")
    print(f"  Highest Checkpoint: {p4.get('highest_checkpoint')}")
    print(f"  Blocker Checkpoint: {p4.get('blocker_checkpoint')}")

    if p4.get("recommended_patches"):
        print()
        print(c(C.BOLD, "  Recommended patches:"))
        for rec in p4.get("recommended_patches", []):
            print(f"    [{rec['priority'].upper()}] {rec['target']}: {rec['action']}")
            print(f"         {rec['reason']}")

    # Auto-Disasm Auto-Triage Trigger
    failure = p4.get("failure_mode", "")
    if "stall" in failure.lower() or "timeout" in failure.lower() or "freeze" in failure.lower():
        # Default stall window to triage if PC is missing or we just know early boot fails
        disasm_range = "0x8004F344:0x8004F4D8"
        print(c(C.MAGENTA, f"\n  [AUTO-TRIAGE] Stall detected. Triggering MIPS Disassembly for window {disasm_range}..."))
        import subprocess
        # Run pipeline purely for disasm output
        disasm_cmd = [
            sys.executable, str(DQ_ROOT / "pipeline.py"),
            "--build-only", "--hbd-lba", "160000",
            "--disasm-range", disasm_range,
            "--disasm-only"
        ]
        try:
            d_out = subprocess.check_output(disasm_cmd, cwd=str(DQ_ROOT), stderr=subprocess.STDOUT, text=True)
            # Filter and print only the disasm lines
            print(c(C.CYAN, "  --- MIPS DISASSEMBLY STREAM ---"))
            for line in d_out.splitlines():
                if "[MIPS DISASM]" in line or "  0x800" in line:
                    print(f"    {line.strip()}")
            print(c(C.CYAN, "  -------------------------------"))
            
            # Save to diagnosis json
            p4["auto_triage_disasm"] = True
            p4["auto_triage_range"] = disasm_range
            diag_path = HYDRA_LOG_DIR / f"iter{iteration}_diagnosis.json"
            with open(diag_path, "w", encoding="utf-8") as f:
                json.dump(p4, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(c(C.RED, f"  [AUTO-TRIAGE] Disassembly extraction failed: {e}"))

    return result


# ---------------------------------------------------------------------------
# Phase 4: Hypothesis & Refinement
# ---------------------------------------------------------------------------

def phase4_refine(iteration: int, analysis: dict) -> dict:
    """Output structured hypothesis and refinement recommendations."""
    phase_header(4, "HYPOTHESIS & REFINEMENT", iteration)

    result = {
        "phase": "refine",
        "iteration": iteration,
        "timestamp": utc_timestamp(),
        "hypothesis": "",
        "recommended_patches": [],
        "next_action": "",
        "should_continue": False,
    }

    diag = analysis.get("diagnosis", {})
    result["hypothesis"] = diag.get("recommended_hypothesis", "")
    result["recommended_patches"] = diag.get("recommended_patches", [])

    # Determine if we should continue iterating
    status = analysis.get("overall_status", "UNKNOWN")
    if status == "OK_RENDERING":
        result["next_action"] = "SUCCESS - disc boots and renders. Hydra loop complete."
        result["should_continue"] = False
    elif status in ("STALL_NO_GPU", "OK_BUT_NO_GPU"):
        result["next_action"] = "PARTIAL - boots but no GPU. Investigate rendering pipeline."
        result["should_continue"] = True
    else:
        result["next_action"] = f"FAILURE - {analysis.get('failure_mode', 'unknown')}. Apply recommended patches and re-iterate."
        result["should_continue"] = True
        print(c(C.RED, f"  FAILURE: {analysis.get('failure_mode', 'unknown')}"))

    if result["recommended_patches"]:
        print()
        print(c(C.BOLD, "  Next iteration actions:"))
        for rec in result["recommended_patches"]:
            pri = rec["priority"].upper()
            priority_color = C.RED if pri == "CRITICAL" else C.YELLOW if pri == "HIGH" else C.CYAN
            print(f"    {c(priority_color, '[' + pri + ']')} {rec['target']}")
            print(f"      Action: {rec['action']}")
            print(f"      Reason: {rec['reason']}")

    return result


# ---------------------------------------------------------------------------
# Main Loop
# ---------------------------------------------------------------------------

def run_hydra_loop(max_iterations: int = 1, build_only: bool = False,
                   test_only: bool = False, smoke_test: bool = False,
                   fail_fast: bool = False, timeout: int = 60,
                   emulator: str = None, bios_mode: str = None,
                   hotfixes: str = None, multi_emulator: bool = False,
                   extra_flags: dict = None) -> int:
    """Run the full Hydra Loop."""
    if extra_flags is None: extra_flags = {}

    banner("PSX MATRIX HYDRA - Autonomous Build/Test/Debug Loop")
    print(f"  Max iterations: {max_iterations}")
    print(f"  Build only:     {build_only}")
    print(f"  Test only:      {test_only}")
    print(f"  Smoke test:     {smoke_test}")
    print(f"  Fail fast:      {fail_fast}")
    print(f"  Timeout:        {timeout}s per test")
    if hotfixes:
        print(f"  Hotfixes:       {hotfixes}")
    print(f"  Disc:           {OUTPUT_BIN}")
    print(f"  Hydra logs:     {HYDRA_LOG_DIR}")

    HYDRA_LOG_DIR.mkdir(parents=True, exist_ok=True)

    all_iterations = []
    final_status = "UNKNOWN"

    for iteration in range(1, max_iterations + 1):
        print()
        print(c(C.MAGENTA + C.BOLD, f"  === HYDRA ITERATION {iteration}/{max_iterations} ==="))

        iter_result = {
            "iteration": iteration,
            "timestamp": utc_timestamp(),
            "phases": {},
        }

        # Phase 1: Build
        if not test_only:
            build_result = phase1_build(iteration, build_only, hotfixes=hotfixes)
            iter_result["phases"]["build"] = build_result

            if not build_result.get("disc_success"):
                print(c(C.RED + C.BOLD, "  Build failed — skipping remaining phases."))
                all_iterations.append(iter_result)
                if fail_fast:
                    break
                continue

            if build_only:
                print(c(C.GREEN, "  Build-only mode — skipping matrix and analysis."))
                all_iterations.append(iter_result)
                final_status = "BUILD_ONLY"
                break

        # Phase 2: Matrix Execution
        if emulator is None and not multi_emulator:
            emulator = "duckstation"
        phase2_result = phase2_matrix(iteration, smoke_test=smoke_test,
                                       fail_fast=fail_fast, timeout=timeout,
                                       emulator=emulator, bios_mode=bios_mode,
                                       multi_emulator=multi_emulator,
                                       extra_flags=extra_flags)
        iter_result["phases"]["matrix"] = phase2_result

        # Phase 3: Telemetry Analysis
        build_log = str(BUILD_LOG)
        if test_only and not BUILD_LOG.exists():
            # Try to find the most recent build log
            logs = sorted(HYDRA_LOG_DIR.glob("iter*_build.log"), reverse=True)
            if logs:
                build_log = str(logs[0])

        analysis_result = phase3_analysis(
            iteration,
            build_log,
            phase2_result["summary_path"],
            phase2_result["log_dir"],
        )
        iter_result["phases"]["analysis"] = analysis_result

        # Phase 4: Hypothesis & Refinement
        refine_result = phase4_refine(iteration, analysis_result)
        iter_result["phases"]["refine"] = refine_result

        all_iterations.append(iter_result)
        final_status = analysis_result.get("overall_status", "UNKNOWN")

        # Check if we should continue
        if not refine_result["should_continue"]:
            break

        if fail_fast and final_status != "PASS":
            print(c(C.YELLOW, "  Fail-fast: stopping iteration loop."))
            break

    # Final summary
    banner("HYDRA LOOP SUMMARY")
    print(f"  Iterations:     {len(all_iterations)}")
    print(f"  Final status:   {final_status}")
    print()

    for ir in all_iterations:
        it = ir["iteration"]
        build = ir["phases"].get("build", {})
        matrix = ir["phases"].get("matrix", {})
        analysis = ir["phases"].get("analysis", {})
        refine = ir["phases"].get("refine", {})

        status = analysis.get("overall_status", "-")
        fm = analysis.get("failure_mode", "-")

        build_ok = "OK" if build.get("disc_success") else "FAIL"
        matrix_ok = f"{matrix.get('passed', 0)}/{matrix.get('total_tests', 0)}"

        print(f"  Iteration {it}: build={build_ok}  matrix={matrix_ok}  "
              f"status={status}  failure={fm}")

    # Save hydra loop summary
    summary_path = HYDRA_LOG_DIR / "hydra_loop_summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump({
            "hydra_run_id": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
            "total_iterations": len(all_iterations),
            "final_status": final_status,
            "iterations": all_iterations,
        }, f, indent=2, ensure_ascii=False)
    print(f"\n  Summary: {summary_path}")

    return 0 if final_status == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(
        description="PSX MATRIX HYDRA — Autonomous Build/Test/Debug Loop",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--max-iterations", type=int, default=1,
        help="Maximum loop iterations (default: 1)",
    )
    parser.add_argument(
        "--build-only", action="store_true",
        help="Only build, skip matrix and analysis",
    )
    parser.add_argument(
        "--test-only", action="store_true",
        help="Skip build, test existing disc + analyze",
    )
    parser.add_argument(
        "--smoke-test", action="store_true",
        help="Quick 30s matrix validation",
    )
    parser.add_argument(
        "--fail-fast", action="store_true",
        help="Stop on first non-PASS result",
    )
    parser.add_argument(
        "--timeout", type=int, default=60,
        help="Per-test timeout in seconds (default: 60)",
    )
    parser.add_argument(
        "--no-color", action="store_true",
        help="Disable ANSI color output",
    )
    parser.add_argument(
        "--emulator", type=str, default=None,
        choices=["cybergrime", "duckstation", "starpsx"],
        help="Run only one emulator in the matrix",
    )
    parser.add_argument(
        "--bios-mode", type=str, default=None,
        choices=["hle", "vhb", "scph"],
        help="Run only one BIOS mode in the matrix",
    )
    parser.add_argument(
        "--multi-emulator", action="store_true",
        help="Run matrix across DuckStation, CyberGrime, and StarPSX simultaneously",
    )
    parser.add_argument(
        "--hotfixes", type=str, default=None,
        help="Path to hotfixes.txt for dynamic CLI patch injection",
    )
    # Extra emulator flags
    parser.add_argument("--region", type=str, default="NTSC_U")
    parser.add_argument("--ds-cpu", type=str, default="Recompiler")
    parser.add_argument("--ds-gpu", type=str, default="Software")
    parser.add_argument("--ds-speed-limit", action="store_true")
    parser.add_argument("--cg-trace-all", action="store_true")
    parser.add_argument("--cg-break", type=str, default=None)
    parser.add_argument("--star-debug", action="store_true")
    parser.add_argument("--star-speed-limit", action="store_true")
    args = parser.parse_args()

    if args.no_color:
        os.environ["NO_COLOR"] = "1"

    return run_hydra_loop(
        max_iterations=args.max_iterations,
        build_only=args.build_only,
        test_only=args.test_only,
        smoke_test=args.smoke_test,
        fail_fast=args.fail_fast,
        timeout=args.timeout,
        emulator=args.emulator,
        bios_mode=args.bios_mode,
        hotfixes=args.hotfixes,
        multi_emulator=args.multi_emulator,
        extra_flags={
            "region": args.region,
            "ds_cpu": args.ds_cpu,
            "ds_gpu": args.ds_gpu,
            "ds_speed_limit": args.ds_speed_limit,
            "cg_trace_all": args.cg_trace_all,
            "cg_break": args.cg_break,
            "star_debug": args.star_debug,
            "star_speed_limit": args.star_speed_limit,
        },
    )


if __name__ == "__main__":
    sys.exit(main())
